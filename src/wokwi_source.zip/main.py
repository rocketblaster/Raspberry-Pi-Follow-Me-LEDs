from machine import Pin, PWM
import utime 
# Define pin
trigger = Pin(28,Pin.OUT)
echo = Pin(27, Pin.IN)
led1 = Pin(12, Pin.OUT)
led2 = Pin(9, Pin.OUT)
led3 = Pin(6, Pin.OUT)
buzzer = PWM(Pin(3))
button = Pin(4, Pin.IN, Pin.PULL_UP)
threshold = 20

def buzzer_on(frequency):
    buzzer.freq(frequency)
    buzzer.duty_u16(200) 

def buzzer_off():
    buzzer.duty_u16(0)

while True:
    trigger.low()
    utime.sleep_us(2)
    trigger.high()
    utime.sleep_us(2)
    trigger.low()
    while echo.value() == 0:
            signaloff = utime.ticks_us()
    while echo.value() == 1:
            signalon = utime.ticks_us()
    timepassed = signalon - signaloff
    distance = (timepassed * 0.0343) / 2
    print("Distance:",distance,"cm")

    if distance <= 20:
        buzzer_on(1000)
        print("Buzzer ON")
    else:
        buzzer_off()
        print("Buzzer OFF")

    led2.value(distance > threshold)
    utime.sleep(0.2)
    led3.value(distance < threshold)
    utime.sleep(0.2)
    
    utime.sleep(1)
    led1.on()      # HIGH
    utime.sleep(0.5)
    led1.off()     # LOW
    utime.sleep(0.5)